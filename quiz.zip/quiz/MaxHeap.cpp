//
//  MaxHeap
//
//  Created by Yizhou on 11/22/22.
//

#include <iostream>
#include <algorithm>

template<class T>
class Maxheap
{
public:
    Maxheap(int size);
    ~Maxheap();
    void Add(T item);
    void Pop(); //Remove the top element
    T top();
private:
    T *heap;
    int currentSize;
    int capacity;
};


template<class T>
Maxheap<T>::Maxheap(int size)
{
    currentSize=0;
    capacity=size;
    heap=new T[capacity+1]; //heap[0]不使用
}


template<class T>
Maxheap<T>::~Maxheap()
{
 delete []heap;
}


template<class T>
T Maxheap<T>::top()
{
  return heap[1];
}


template<class T>
void Maxheap<T>::Add(T element)
{
    currentSize++;
    int position=currentSize;
    while(position>1 && heap[position/2]<element){
        std::swap(heap[position],heap[position/2]);
        position=position/2;
     }
    heap[position]=element;
}


template<class T>
void Maxheap<T>::Pop()
{
   T last=heap[currentSize];
   currentSize--;
   int currentNode=1;
   int child=2;
   while(child<=currentSize)
   {
     if(child<currentSize && heap[child]<heap[child+1])
        child++;
     if(last>=heap[child])
         break;
     else
     {
      heap[currentNode]=heap[child];
      currentNode=child;
      child=child*2;
     }
   }
   heap[ currentNode]=last;
}

int main(int argc, const char * argv[]) {
    Maxheap<int> a(8);
    a.Add(20);
    a.Add(30);
    a.Add(90);
    std::cout<<a.top()<<std::endl;
    a.Pop();
    std::cout<<a.top()<<std::endl;
    return 0;
}
