#include <iostream>
#include "DNode.hpp"

template<typename T>
DNode<T>::DNode(){}

template<typename T>
DNode<T>::~DNode(){}
