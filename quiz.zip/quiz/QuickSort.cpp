//
//  QuickSort
//
//  Created by Yizhou Wang on 11/22/22.
//

#include <iostream>
#include <algorithm>
#include <vector>

int changeLocation(std::vector<int>& input, int begin, int end){
    int pivot = input[end];
    int index = begin;
    for (int i=begin;i<end;i++){
        if (input[i]<=pivot){
            std::swap(input[i],input[index]);
            index++;
        }
    }
    std::swap(input[index],input[end]);
    return index;
}

void quicksort(std::vector<int>& input, int begin, int end){
    if (begin>=end) return;
    int index = changeLocation(input,begin,end);
    quicksort(input,begin,index-1);
    quicksort(input,index+1,end);
    
}

int main(int argc, const char * argv[]) {
    std::vector<int> a {1,5,4,6,9,-1};
    quicksort(a,0,6);
    for (auto i:a) std::cout<<i<<" ";
}
